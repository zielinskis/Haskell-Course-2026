# UiLayoutLang

A small Haskell project for parsing simple UI layouts, computing box positions, and drawing the result in the terminal.

## Run

From this folder:

```powershell
runghc project.hs test
runghc project.hs layout input.txt
runghc project.hs render input.txt
```

## Example input

```txt
window 800 x 600 {
  row {
    box { width: 20%; height: 100%; color: red }
    box { width: 80%; height: 100%; color: blue }
  }
}
```

`layout` prints numbers. `render` prints a simple terminal picture.
